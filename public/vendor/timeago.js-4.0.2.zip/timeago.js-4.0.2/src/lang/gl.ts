export default function(number: number, index: number): [string, string] {
  return [
    ['xusto agora', 'daquí a un pouco'],
    ['hai %s segundos', 'en %s segundos'],
    ['hai 1 minuto', 'nun minuto'],
    ['hai %s minutos', 'en %s minutos'],
    ['hai 1 hora', 'nunha hora'],
    ['hai %s horas', 'en %s horas'],
    ['hai 1 día', 'nun día'],
    ['hai %s días', 'en %s días'],
    ['hai 1 semana', 'nunha semana'],
    ['hai %s semanas', 'en %s semanas'],
    ['hai 1 mes', 'nun mes'],
    ['hai %s meses', 'en %s meses'],
    ['hai 1 ano', 'nun ano'],
    ['hai %s anos', 'en %s anos'],
  ][index] as [string, string];
}
