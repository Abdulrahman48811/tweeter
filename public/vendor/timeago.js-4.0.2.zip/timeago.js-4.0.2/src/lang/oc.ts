export default function(number: number, index: number): [string, string] {
  return [
    ['fa un moment', "d'aquí un moment"],
    ['fa %s segondas', "d'aquí %s segondas"],
    ['fa 1 minuta', "d'aquí 1 minuta"],
    ['fa %s minutas', "d'aquí %s minutas"],
    ['fa 1 ora', "d'aquí 1 ora"],
    ['fa %s oras', "d'aquí %s oras"],
    ['fa 1 jorn', "d'aquí 1 jorn"],
    ['fa %s jorns', "d'aquí %s jorns"],
    ['fa 1 setmana', "d'aquí 1 setmana"],
    ['fa %s setmanas', "d'aquí %s setmanas"],
    ['fa 1 mes', "d'aquí 1 mes"],
    ['fa %s meses', "d'aquí %s meses"],
    ['fa 1 an', "d'aquí 1 an"],
    ['fa %s ans', "d'aquí %s ans"],
  ][index] as [string, string];
}
