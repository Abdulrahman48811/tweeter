export default function(number: number, index: number): [string, string] {
  return [
    ['poco fa', 'fra poco'],
    ['%s secondi fa', 'fra %s secondi'],
    ['un minuto fa', 'fra un minuto'],
    ['%s minuti fa', 'fra %s minuti'],
    ["un'ora fa", "fra un'ora"],
    ['%s ore fa', 'fra %s ore'],
    ['un giorno fa', 'fra un giorno'],
    ['%s giorni fa', 'fra %s giorni'],
    ['una settimana fa', 'fra una settimana'],
    ['%s settimane fa', 'fra %s settimane'],
    ['un mese fa', 'fra un mese'],
    ['%s mesi fa', 'fra %s mesi'],
    ['un anno fa', 'fra un anno'],
    ['%s anni fa', 'fra %s anni'],
  ][index] as [string, string];
}
